#!/bin/bash

helm upgrade --install fico-gateway-test --force ./ --debug -n openlabs
